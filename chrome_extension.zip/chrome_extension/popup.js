document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get(['username', 'token'], (data) => {
        // Prefill username from storage
        const usernameInput = document.getElementById('username');
        if (data.username && usernameInput) {
            usernameInput.value = data.username;
        }
        // If logged in, load search UI
        if (data.token) {
            loadSearchUI();
            return;
        }
        // Fetch username from API if not in storage
        fetch('http://127.0.0.1:8000/api/get_username/', {
            method: 'GET',
            headers: { 'Authorization': `Token ${data.token || ''}` }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            return response.json();
        })
        .then(apiData => {
            if (apiData.username && usernameInput) {
                usernameInput.value = apiData.username;
                chrome.storage.local.set({ username: apiData.username });
            }
        })
        .catch(err => {
            console.error('Error fetching username:', err);
        });
    });
    document.getElementById('loginButton').addEventListener('click', authenticate);
});

function authenticate() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('master_password').value;
    const errorDiv = document.getElementById('error');
    const contentDiv = document.getElementById('content');

    if (!username || !password) {
        errorDiv.textContent = 'Username and password required';
        return;
    }

    fetch('http://127.0.0.1:8000/api/login/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, master_password: password })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.token) {
            chrome.storage.local.set({ token: data.token, username }, () => {
                chrome.storage.session.set({ master_password: password }, () => {
                    loadSearchUI();
                });
            });
        } else {
            errorDiv.textContent = data.error || 'Authentication failed';
        }
    })
    .catch(err => {
        errorDiv.textContent = 'Error connecting to CryptVault: ' + err.message;
        console.error(err);
    });
}

// In popup.js, update the loadSearchUI function:
function loadSearchUI() {
    const contentDiv = document.getElementById('content');
    const loginForm = document.querySelector('.glass-card');
    
    // Hide the entire login form
    if (loginForm) {
        loginForm.style.display = 'none';
    }
    
    fetch(chrome.runtime.getURL('search.html'))
        .then(response => response.text())
        .then(html => {
            contentDiv.innerHTML = html;
            const script = document.createElement('script');
            script.src = chrome.runtime.getURL('search.js');
            document.body.appendChild(script);
            
            // Remove these lines as they're not needed anymore
            // document.getElementById('username').style.display = 'none';
            // document.getElementById('master_password').style.display = 'none';
            // document.getElementById('loginButton').style.display = 'none';
            
            document.getElementById('error').textContent = '';
            // Rest of the function remains the same
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs.length > 0) {
                    chrome.storage.local.set({ current_url: tabs[0].url }, () => {
                        const urlInput = document.getElementById('url');
                        if (urlInput) {
                            urlInput.value = tabs[0].url;
                            search();
                        }
                    });
                }
            });
        })
        .catch(err => {
            document.getElementById('error').textContent = 'Failed to load search: ' + err.message;
            console.error(err);
        });
}